"use strict";
exports.id = 262;
exports.ids = [262];
exports.modules = {

/***/ 1262:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ index)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./common/Header.js



function Header() {
    const [product, setProduct] = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        if (localStorage) {
            const localStorageData = localStorage.getItem("cartData");
            setProduct(JSON.parse(localStorageData));
        }
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "bg-light",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " d-flex justify-content-between",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/dashboard",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "m-3",
                                children: "home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/catagory",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "m-3",
                                children: "catagory"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: " m-3 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/addToCart",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    className: "btn btn-primary p-2",
                                    children: [
                                        "Add To Cart (",
                                        product === null || product === void 0 ? void 0 : product.length,
                                        ")",
                                        " "
                                    ]
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/App/index.js



function index(props) {
    const { children  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
            children
        ]
    });
}


/***/ })

};
;